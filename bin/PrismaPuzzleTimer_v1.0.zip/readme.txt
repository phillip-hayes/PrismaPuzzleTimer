# PrismaPuzzleTimer

Timer application for cube speed solvers

Original source cloned from:

	https://bitbucket.org/walter/puzzle-timer/

	
Changes from original Prisma timer release:
    Support for StackMat Gen 3 timer. New API library developed:
          https://github.com/phillip-hayes/StackMatGen3TimerAPI
    Options -> Timer Trigger -> Stackmat Gen 3 Timer
    Display changed to 3 decimal places to match gen 3 timer output